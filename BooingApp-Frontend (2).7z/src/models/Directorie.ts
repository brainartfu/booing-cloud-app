export interface Directorie {
  createdAt: string;
  id: string;
  isDirectory: boolean;
  items: number;
  name: string;
  type: number;
}
