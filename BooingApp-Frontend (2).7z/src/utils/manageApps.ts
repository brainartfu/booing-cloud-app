import {  NativeModules } from "react-native";
const {ManageApps} = NativeModules;

export default ManageApps;