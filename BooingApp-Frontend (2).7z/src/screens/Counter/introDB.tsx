const slides = [
  {
    id: 1,
    des: "un nuovo servizio cloud sicuro, conveniente, green ",
  },
  {
    id: 2,
    des: "iene pulito il tuo dispositivo recuperando spazio prezioso ",
  },
  {
    id: 3,
    des: "rammenta e cripta i file in milioni di piccoli frammenti creando copie in modo da renderli inattaccabili e sempre disponibili ",
  },
  {
    id: 4,
    des: "icicla grandi quantità di spazio ed energia e ne crea un servizio cloud altamente affidabile ",
  },
  {
    id: 5,
    des: "aga lo spazio direttamente agli utenti e lo trasforma per renderlo sicuro ed efficiente ",
  },
  {
    id: 6,
    des: "appresenta una vera e propria rivoluzione nel mercato del cloud computing  in grado di coadiuvare le necessità di avere sempre più spazio a disposizione e quella di consumare meno energia con un focus specifico sulla sicurezza",
  },
];
export default slides;
