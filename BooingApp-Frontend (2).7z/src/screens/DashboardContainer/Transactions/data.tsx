
export const testData = [
{
	status: 4,
	amount: 5000,
	date: '2023-03-17T12:02:02Z',
	before: 10000,
	after: 15000,
	info: 'you selled 1G'
},
{
	status: 1,
	amount: 5000,
	date: '2023-03-18T12:02:02Z',
	before: 10000,
	after: 15000,
	info: 'you selled 1G'
},
{
	status: 1,
	amount: 5000,
	date: '2023-03-18T02:02:02Z',
	before: 10000,
	after: 15000,
	info: 'you selled 1G'
},
{
	status: 1,
	amount: 5000,
	date: '2023-03-18T02:02:02Z',
	before: 10000,
	after: 15000,
	info: 'you selled 1G'
},
{
	status: 4,
	amount: 5000,
	date: '2023-03-18T02:02:02Z',
	before: 10000,
	after: 15000,
	info: 'you selled 1G'
},
{
	status: 4,
	amount: 5000,
	date: '2023-03-18T02:02:02Z',
	before: 10000,
	after: 15000,
	info: 'you selled 1G'
},
]