export const offerdata = [
  {
    monthly: 0.93,
    yearly: 10,
    space: "100G",
    id: "Pluse-100G",
    quantity: 1,
  },
  {
    monthly: 2.70,
    yearly: 20,
    space: "500G",
    id: "Pluse-500G",
    quantity: 1,
  },
  {
    monthly: 3.3,
    yearly: 30,
    space: "1T",
    id: "Pluse-1T",
    quantity: 1,
  },
  {
    monthly: 5.7,
    yearly: 45,
    space: "5T",
    id: "Pluse-5T",
    quantity: 1,
  },
  {
    monthly: 9.7,
    yearly: 80,
    space: "10T",
    id: "Pluse-10T",
    quantity: 1,
  },
  {
    monthly: 18.3,
    yearly: 140,
    space: "50T",
    id: "Pluse-50T",
    quantity: 1,
  }  
]