export {default as HomeIcon} from './HomeIcon'
export {default as FilesIcon} from './FilesIcon'
export {default as AccountIcon} from './AccountIcon'
