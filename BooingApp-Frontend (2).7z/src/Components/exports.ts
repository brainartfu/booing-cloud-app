export {default as Loader} from './Loader/Loader'
export {default as SocialMediaAuth} from './SocialMediaAuth/SocialMediaAuth'